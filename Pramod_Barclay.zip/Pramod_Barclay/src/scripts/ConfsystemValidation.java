package scripts;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;
import Driver.LaunchApplication;
import Driver.ReadExcel;

public class ConfsystemValidation extends LaunchApplication {
	
	public static String Confsystemvalidation(HashMap<String, String> hm)
	{
		try{
			
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="ConfsystemValidation";
			screenshot=screenshot+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.findElement(By.id("element_button_3")).click();
			System.out.println("admin");
			Thread.sleep(1000);
			
			driver.findElement(By.id("grid_column_7_clps_div")).click();
			
			driver.findElement(By.xpath("//*[@id='element_label_25']")).click();
			
			driver.findElement(By.xpath("//*[@id='settingValue0']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue0']")).sendKeys(hm.get("AVAForExportButtonVisibility"));
			driver.findElement(By.xpath("//*[@id='settingValue1']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue1']")).sendKeys(hm.get("AVAVariancePercentage"));
			driver.findElement(By.xpath("//*[@id='settingValue2']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue2']")).sendKeys(hm.get("BarclaysBusinessFeedbackEmail"));
			driver.findElement(By.xpath("//*[@id='settingValue3']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue3']")).sendKeys(hm.get("BarclaysBusinessValutionTeamEmail"));
			driver.findElement(By.xpath("//*[@id='settingValue4']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue4']")).sendKeys(hm.get("BarclaysCorporateFeedbackEmail"));
			driver.findElement(By.xpath("//*[@id='settingValue5']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue5']")).sendKeys(hm.get("BarclaysCorporateValutionTeamEmail"));
			driver.findElement(By.xpath("//*[@id='settingValue6']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue6']")).sendKeys(hm.get("BarclaysWealthFeedbackEmail"));
			driver.findElement(By.xpath("//*[@id='settingValue7']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue7']")).sendKeys(hm.get("BarclaysWealthValutionTeamEmail"));
			driver.findElement(By.xpath("//*[@id='settingValue8']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue8']")).sendKeys(hm.get("MisuseNotificationDaysCount"));
			driver.findElement(By.xpath("//*[@id='settingValue9']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue9']")).sendKeys(hm.get("MisuseNotificationOccurenceCount"));
			driver.findElement(By.xpath("//*[@id='settingValue10']")).clear();
			driver.findElement(By.xpath("//*[@id='settingValue10']")).sendKeys(hm.get("PIIExpiryGracePeriodDays"));
			
			driver.findElement(By.xpath("//*[@id='element_button_1']")).click();
		    
		    ExpectedResult = hm.get("Act_Message");
		    ActualResult= driver.getPageSource();
             System.out.println("Message is:"+ExpectedResult);
			
			if(ActualResult.contains(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
		    
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return null;
		
	}

}
