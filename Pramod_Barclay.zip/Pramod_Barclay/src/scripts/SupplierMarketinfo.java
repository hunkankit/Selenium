package scripts;

import java.util.HashMap;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.Select;

import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;
import Driver.LaunchApplication;
import Driver.ReadExcel;

public class SupplierMarketinfo extends LaunchApplication {
	
	public static String Suppliermarketinfo(HashMap<String, String> hm)
	{
     
		try{
			
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="SupplierMarketinfo";
			screenshot=screenshot+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			driver.findElement(By.id("element_button_3")).click();
			System.out.println("admin");
			Thread.sleep(1000);
			
			driver.findElement(By.id("grid_column_7_clps_div")).click();
						
			driver.findElement(By.xpath("//*[@id='element_label_17']")).click();
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//*[@id='viewAccordId_clsp_anchor']")).click();
			
			Select supplier = new Select(driver.findElement(By.id("allSuppliersId")));
			supplier.selectByVisibleText(hm.get("Supplier_Name"));
			
		/*	List<WebElement> listOfLiElements = driver.findElements(By.xpath("//*[@id='element_label_1_ctrl_div']/div"));
			for(int i=0; i< listOfLiElements.size(); i++){
				//listOfLiElements.get(i).click();
				if(listOfLiElements.get(i).getText().equalsIgnoreCase("UK (Wealth)")){
					listOfLiElements.get(i).findElement(By.id("21"));
					listOfLiElements.get(i).click();	
					break;
				}
			}*/
			
			driver.findElement(By.xpath("//*[@id='element_icon_2']")).click();
			driver.findElement(By.xpath("//*[@id='grid_column_4_clsp_anchor']")).click();
			
			
			if(hm.containsKey("PII_Amount1")&& !hm.get("PII_Amount1").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='panelSupplierMarkets__piiCoverageAmountUnadjustedLocal']")).clear();
				driver.findElement(By.xpath("//*[@id='panelSupplierMarkets__piiCoverageAmountUnadjustedLocal']")).sendKeys(hm.get("PII_Amount1"));
				System.out.println("value:  "+hm.get("PII_Amount1"));
			}
			
			if(hm.containsKey("PII_Amount2")&& !hm.get("PII_Amount2").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='panelSupplierMarkets__piiCoverageAmountUnadjustedSterling']")).clear();
				driver.findElement(By.xpath("//*[@id='panelSupplierMarkets__piiCoverageAmountUnadjustedSterling']")).sendKeys(hm.get("PII_Amount2"));
				System.out.println("value:  "+hm.get("PII_Amount2"));
			}
			
			
		
			//driver.findElement(By.xpath("//*[@id='panelSupplierMarkets__suppressPiiExpiryEmail']")).click();
			
			driver.findElement(By.xpath("//*[@id='element_button_1']")).click();
			
			
			ExpectedResult=hm.get("Exp_Message");
			ActualResult=driver.getPageSource();
			
			if(ActualResult.contains(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			
					
						
		}catch(Exception e)
		
		{
			System.out.println(e.getMessage());
		}

		
		return null;
		
	}

}
