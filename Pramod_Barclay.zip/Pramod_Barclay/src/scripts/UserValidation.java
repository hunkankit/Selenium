package scripts;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;
import Driver.LaunchApplication;
import Driver.ReadExcel;

public class UserValidation extends LaunchApplication{
	
	public static String Uservalidation(HashMap<String, String> hm)
	{
		
    try{			
			
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="UserValidation";
			screenshot=screenshot+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			driver.findElement(By.id("element_button_3")).click();
			System.out.println("admin");
			Thread.sleep(1000);
			
			driver.findElement(By.id("grid_column_7_clps_div")).click();
			
			driver.findElement(By.xpath("//*[@id='element_label_22']")).click();
						
			driver.findElement(By.xpath("//*[@id='grid_column_3_clsp_anchor']")).click();
			Select user = new Select(driver.findElement(By.id("allUsersId")));
			user.selectByVisibleText(hm.get("User_id"));
			
			
			driver.findElement(By.id("userDetails__firstName")).clear();
			driver.findElement(By.id("userDetails__firstName")).sendKeys(hm.get("New_First_Name"));
			driver.findElement(By.id("userDetails__lastName")).clear();
			driver.findElement(By.id("userDetails__lastName")).sendKeys(hm.get("New_Last_Name"));
			
			Select role = new Select(driver.findElement(By.xpath("//*[@id='userDetails__roleId']")));
			role.selectByVisibleText(hm.get("Role"));
			
			Select business = new Select(driver.findElement(By.xpath("//*[@id='userDetails__businessAreaId']")));
			business.selectByVisibleText(hm.get("Business_Area"));
			
			driver.findElement(By.xpath("//*[@id='userDetails__emailAddress']")).clear();
			driver.findElement(By.xpath("//*[@id='userDetails__emailAddress']")).sendKeys(hm.get("Email"));
			
			driver.findElement(By.xpath("//*[@id='element_button_1']")).click();
		
			ExpectedResult=hm.get("Exp_Message");
			ActualResult=driver.getPageSource();
			
			if(ActualResult.contains(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
		
			
		}catch(Exception e)
		
		{
			System.out.println(e.getMessage());
		
		
		
		
	}
		
		return null;
		
	}

}
