package scripts;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;
import Driver.LaunchApplication;
import Driver.ReadExcel;

public class EditZone extends LaunchApplication {
	
	public static String Editzone(HashMap<String, String> hm)
	{
		
      try{			
			
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="EditZone";
			screenshot=screenshot+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			driver.findElement(By.id("element_button_3")).click();
			driver.findElement(By.id("grid_column_7_clps_div")).click();
			
			driver.findElement(By.xpath("//*[@id='element_label_20']")).click();				
			//driver.findElement(By.xpath("//p[.='Manage Suppliers']")).click();
			
			Select market = new Select(driver.findElement(By.id("allMarketsZoneId")));
			market.selectByVisibleText(hm.get("Markets"));
			
			Select zone = new Select(driver.findElement(By.id("zonesId")));
			zone.selectByVisibleText(hm.get("Zone_Name"));
			
			driver.findElement(By.xpath("//div[@id='page-body_undefined']/div/div[3]/div/div[2]/div/div//div[@id='grid_column_5_clps_div']")).click();
			driver.findElement(By.id("updateZone__zoneName")).sendKeys(hm.get("New_Zone_Name"));
			driver.findElement(By.id("element_button_3")).click();
			
			ExpectedResult="A new Zone has been created";
			ActualResult=driver.findElement(By.xpath("")).getText();
			
			if(ActualResult.contains(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
		
			
		}catch(Exception e)
		
		{
			System.out.println(e.getMessage());
		
		
		
		
	}
		
		return null;
	
	

}
}