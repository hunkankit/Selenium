package scripts;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;
import Driver.LaunchApplication;
import Driver.ReadExcel;

public class EditUser extends LaunchApplication {
	
	public static String Edituser(HashMap<String, String> hm)
	{
		
		
      try{			
			
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="EditUser";
			screenshot=screenshot+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			driver.findElement(By.id("element_button_3")).click();
			System.out.println("admin");
			Thread.sleep(1000);
			
			driver.findElement(By.id("grid_column_7_clps_div")).click();
			
			driver.findElement(By.xpath("//*[@id='element_label_22']")).click();
						
			driver.findElement(By.xpath("//*[@id='grid_column_3_clsp_anchor']")).click();
			Select user = new Select(driver.findElement(By.id("allUsersId")));
			user.selectByVisibleText(hm.get("User_id"));
		    
			if(hm.containsKey("New_First_Name")&& !hm.get("New_First_Name").equalsIgnoreCase("null"))
			{
				driver.findElement(By.id("userDetails__firstName")).clear();
				driver.findElement(By.id("userDetails__firstName")).sendKeys(hm.get("New_First_Name"));
				System.out.println("value:  "+hm.get("New_First_Name"));
			}
			
			if(hm.containsKey("New_Last_Name")&& !hm.get("New_Last_Name").equalsIgnoreCase("null"))
			{
				driver.findElement(By.id("userDetails__lastName")).clear();
				driver.findElement(By.id("userDetails__lastName")).sendKeys(hm.get("New_Last_Name"));
				System.out.println("value:  "+hm.get("New_Last_Name"));
			}
			
			if(hm.containsKey("Role")&& !hm.get("Role").equalsIgnoreCase("null"))
			{
				Select role = new Select(driver.findElement(By.xpath("//*[@id='userDetails__roleId']")));
				role.selectByVisibleText(hm.get("Role"));
				System.out.println("value:  "+hm.get("Role"));
			}
			
			if(hm.containsKey("Business_Area")&& !hm.get("Business_Area").equalsIgnoreCase("null"))
			{
				Select business = new Select(driver.findElement(By.xpath("//*[@id='userDetails__businessAreaId']")));
				business.selectByVisibleText(hm.get("Business_Area"));
				System.out.println("value:  "+hm.get("Business_Area"));
			}
			
			if(hm.containsKey("Email")&& !hm.get("Email").equalsIgnoreCase("null"))
			{
				driver.findElement(By.id("userDetails__lastName")).clear();
				driver.findElement(By.id("userDetails__lastName")).sendKeys(hm.get("Email"));
				System.out.println("value:  "+hm.get("Email"));
			}
			
		
			
			driver.findElement(By.xpath("//*[@id='element_button_1']")).click();
			
			ExpectedResult="User information updated for user";
			ActualResult=driver.findElement(By.xpath("//*[@id='responseId']")).getText();
			
			if(ActualResult.contains(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
		
			
		}catch(Exception e)
		
		{
			System.out.println(e.getMessage());
		
		
		
		
	}
		
		return null;
		
	}

}
