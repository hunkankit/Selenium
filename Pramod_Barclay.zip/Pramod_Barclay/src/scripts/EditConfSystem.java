package scripts;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;
import Driver.LaunchApplication;
import Driver.ReadExcel;

public class EditConfSystem extends LaunchApplication{
	
	public static String Editconfsystem(HashMap<String, String> hm)
	{
		
		
     try{
							
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="EditConfSystem";
			screenshot=screenshot+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.findElement(By.id("element_button_3")).click();
			System.out.println("admin");
			Thread.sleep(1000);
			
			driver.findElement(By.id("grid_column_7_clps_div")).click();
			
			driver.findElement(By.xpath("//*[@id='element_label_25']")).click();
			
			if(hm.containsKey("AVAForExportButtonVisibility")&& !hm.get("AVAForExportButtonVisibility").equalsIgnoreCase("null"))
			{
				driver.findElement(By.id("settingValue0")).clear();
				driver.findElement(By.id("settingValue0")).sendKeys(hm.get("AVAForExportButtonVisibility"));
				System.out.println("value:  "+hm.get("AVAForExportButtonVisibility"));
			}
			
			if(hm.containsKey("AVAVariancePercentage")&& !hm.get("AVAVariancePercentage").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue1']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue1']")).sendKeys(hm.get("AVAVariancePercentage"));
				System.out.println("value:  "+hm.get("AVAVariancePercentage"));
			}
			
			if(hm.containsKey("BarclaysBusinessFeedbackEmail")&& !hm.get("BarclaysBusinessFeedbackEmail").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue2']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue2']")).sendKeys(hm.get("BarclaysBusinessFeedbackEmail"));
				System.out.println("value:  "+hm.get("BarclaysBusinessFeedbackEmail"));
			}
			
			if(hm.containsKey("BarclaysBusinessValutionTeamEmail")&& !hm.get("BarclaysBusinessValutionTeamEmail").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue3']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue3']")).sendKeys(hm.get("BarclaysBusinessValutionTeamEmail"));
				System.out.println("value:  "+hm.get("BarclaysBusinessValutionTeamEmail"));
			}
			
			if(hm.containsKey("BarclaysCorporateFeedbackEmail")&& !hm.get("BarclaysCorporateFeedbackEmail").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue4']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue4']")).sendKeys(hm.get("BarclaysCorporateFeedbackEmail"));
				System.out.println("value:  "+hm.get("BarclaysCorporateFeedbackEmail"));
			}
			
			if(hm.containsKey("BarclaysCorporateValutionTeamEmail")&& !hm.get("BarclaysCorporateValutionTeamEmail").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue5']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue5']")).sendKeys(hm.get("BarclaysCorporateValutionTeamEmail"));
				System.out.println("value:  "+hm.get("BarclaysCorporateValutionTeamEmail"));
			}
			
			if(hm.containsKey("BarclaysWealthFeedbackEmail")&& !hm.get("BarclaysWealthFeedbackEmail").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue6']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue6']")).sendKeys(hm.get("BarclaysWealthFeedbackEmail"));
				System.out.println("value:  "+hm.get("BarclaysWealthFeedbackEmail"));
			}
			
			if(hm.containsKey("BarclaysWealthValutionTeamEmail")&& !hm.get("BarclaysWealthValutionTeamEmail").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue7']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue7']")).sendKeys(hm.get("BarclaysWealthValutionTeamEmail"));
				System.out.println("value:  "+hm.get("BarclaysWealthValutionTeamEmail"));
			}
			
			if(hm.containsKey("MisuseNotificationDaysCount")&& !hm.get("MisuseNotificationDaysCount").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue8']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue8']")).sendKeys(hm.get("MisuseNotificationDaysCount"));
				System.out.println("value:  "+hm.get("MisuseNotificationDaysCount"));
			}
			
			if(hm.containsKey("MisuseNotificationOccurenceCount")&& !hm.get("MisuseNotificationOccurenceCount").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue9']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue9']")).sendKeys(hm.get("MisuseNotificationOccurenceCount"));
				System.out.println("value:  "+hm.get("MisuseNotificationOccurenceCount"));
			}
			
			if(hm.containsKey("PIIExpiryGracePeriodDays")&& !hm.get("PIIExpiryGracePeriodDays").equalsIgnoreCase("null"))
			{
				driver.findElement(By.xpath("//*[@id='settingValue10']")).clear();
				driver.findElement(By.xpath("//*[@id='settingValue10']")).sendKeys(hm.get("PIIExpiryGracePeriodDays"));
				System.out.println("value:  "+hm.get("PIIExpiryGracePeriodDays"));
			}
			
			
			driver.findElement(By.xpath("//*[@id='element_button_1']")).click();
			
			Thread.sleep(1000);
		    ExpectedResult = "The Configuration System has been updated";
		    ActualResult= driver.findElement(By.xpath("//*[@id='responseId']")).getText();
             System.out.println("Message is:"+ActualResult);
			
			if(ActualResult.contains(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
		    
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return null;
		
	}

}
