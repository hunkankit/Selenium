package scripts;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;

import Driver.LaunchApplication;
import Driver.ReadExcel;

public class SearchtemplateAddproperty extends LaunchApplication {
	
	public static String Searchtemplateaddproperty(HashMap<String, String> hm)
	{
		
        try{
			
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="SearchtemplateAddproperty";
			screenshot=screenshot+TestCaseId;
			
			driver.get(PropertyRead.TestURL);
			driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.findElement(By.id("element_button_3")).click();
			driver.findElement(By.id("grid_column_5_clsp_anchor")).click();
			
			driver.findElement(By.xpath("//ul[@id='fgp_container_list_1_ul']/li[2]")).click();	
			driver.findElement(By.xpath("//*[@id='element_button_2']")).click();
			driver.findElement(By.xpath("//*[@id='element_button_2']")).click();
		    
			ExpectedResult = "Property2";
		    ActualResult= driver.findElement(By.xpath("//div[@id='property2']/div/div/div[1]/h4")).getText();
             System.out.println("Message is:"+ActualResult);
			
			if(ActualResult.equals(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;
				
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
			
			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}
		    
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
		
	}

}
