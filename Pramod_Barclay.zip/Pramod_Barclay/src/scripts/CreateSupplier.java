package scripts;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import Driver.LaunchApplication;
import Driver.ReadExcel;
import commonclasses.PropertyRead;
import commonclasses.TakeScreenShot;

public class CreateSupplier extends LaunchApplication {

	public String Createsupplier(HashMap<String, String> hm)
	{

		try{

			System.out.println("You are in Create Supplier");
			System.out.println("values in HashMap: "+hm);
			String ActualResult="";
			String ExpectedResult="";
			String TestCaseId=hm.get("TC_ID").toString();
			String TestCaseDesc=hm.get("TC_Desc").toString();
			String classname=hm.get("ClassName").toString();
			String return_result=null;	
			String screenshot="CreateSupplier";
			screenshot=screenshot+TestCaseId;

			driver.get(PropertyRead.TestURL);
			System.out.println("Testing "+driver.getCurrentUrl());
			driver.manage().window().maximize();

			WebDriverWait driverWait = new WebDriverWait(driver, 40);
			driverWait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(".//*[@id='element_button_3']"))));


			driver.findElement(By.id("element_button_3")).click();
//			System.out.println("crete admin : "+driver.findElement(By.id("element_button_3")).getText());
			//Thread.sleep(1000);
			//driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			//driver.findElement(By.xpath("//*[@id='grid_column_7_clsp_anchor']")).click();
			Thread.sleep(2000);
			driver.findElement(By.id("grid_column_7_clsp_anchor")).click();
			//driver.findElement(By.id("grid_column_7_clps_div")).click();
 
			driver.findElement(By.xpath("//*[@id='element_label_17']")).click();

			driver.findElement(By.id("grid_column_6_clsp_anchor")).click();
			//driver.findElement(By.xpath("//div[@id='page-body_undefined']/div/div[3]/div/div/div/div/div[1]//div[@id='grid_column_6_clps_div']")).click();
			
			Thread.sleep(3000);
		//	System.out.println("driver tittle: "+ driver.findElement(By.id("grid_column_6_clsp_anchor")).getTagName());
			//#supplierNameID
		//	driver.findElement(By.xpath("//*[@id='supplierNameID']")).click();
			//*[@id="supplierNameID"]
			
		//	WebElement Supplier_Name = driver.findElement(By.id("supplierNameID"));
			System.out.println("Supplier name : "+hm.get("Supplier_Name"));
			//System.out.println("Supplier_Name: "+Supplier_Name.getTagName());
		//	Supplier_Name.sendKeys("abSupp8");
			
		/*	 Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				       .withTimeout(30, TimeUnit.SECONDS)
				       .pollingEvery(5, TimeUnit.SECONDS).
				       ignoring(NoSuchElementException.class);*/
	//		WebElement Supplier_Name = wait.until(elementToBeClickable(By.id("supplierNameID")));
	//		Supplier_Name.sendKeys(hm.get("Supplier_Name"));
			// wait.until(Supplier_Name);
			/* WebElement Supplier_Name = wait.until(new Function<WebDriver, WebElement>() {
			     public WebElement apply(WebDriver driver) {
			       return driver.findElement(By.id("supplierNameID"));
			     }
			   });*/
			
	//		clickWhenReady(By.id("supplierNameID"),3);
//			sendKeyWhenReady(By.id("supplierNameID"),hm.get("Supplier_Name"));
//			checkPresence(By.id("supplierNameID")).sendKeys(hm.get("Supplier_Name"));
			getWhenVisible(By.id("supplierNameID"),3).sendKeys(hm.get("Supplier_Name"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].setAttribute=('value','%s');",hm.get("Supplier_Name"));
	//		Supplier_Name.sendKeys(hm.get("Supplier_Name").toString());
	//		driver.findElement(By.xpath("//*[@id='supplierNameID']")).sendKeys(hm.get("Supplier_Name"));
			
			/*driver.findElement(By.xpath("//*[@id='tradingNameID']")).click();
			driver.findElement(By.xpath("//*[@id='tradingNameID']")).sendKeys(hm.get("Trading_Name"));
			*/
	//		JavascriptExecutor Trading_Name = (JavascriptExecutor)driver;
			executor.executeScript("arguments[1].setAttribute=('value','%s');",hm.get("Trading_Name"));
			/*
			driver.findElement(By.xpath("//*[@id='sortCodeID']")).click();
			driver.findElement(By.xpath("//*[@id='sortCodeID']")).sendKeys(hm.get("Sort_Code"));*/
			
//			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[2].setAttribute=('value','%s');",hm.get("Sort_Code"));
			
			/*driver.findElement(By.xpath("//*[@id='accNoID']")).click();
			driver.findElement(By.xpath("//*[@id='accNoID']")).sendKeys(hm.get("Account_Number"));*/
			
	//		JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[3].setAttribute=('value','%s');",hm.get("Account_Number"));
	/*		
			driver.findElement(By.xpath("//*[@id='emailID']")).click();
			driver.findElement(By.xpath("//*[@id='emailID']")).sendKeys(hm.get("Email"));*/
			
	//		JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[4].setAttribute=('value','%s');",hm.get("Email"));

			driver.findElement(By.xpath("//*[@id='createSuppAttestID']")).click();
			driver.findElement(By.xpath("//*[@id='element_button_2']")).click();

			Thread.sleep(5000);
			System.out.println("Title : "+driver.getTitle());

			ExpectedResult="A new Supplier has been created";
			ActualResult=driver.findElement(By.xpath("//*[@id='grid_column_10_seccol_mdl_div']")).getText();

			if(ActualResult.contains(ExpectedResult))
			{
				return_result="Pass"+","+TestCaseId+","+TestCaseDesc;

				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}

			else
			{
				return_result="Fail"+","+TestCaseId+","+TestCaseDesc;
				System.out.println("Return Result is: "+return_result);
				TakeScreenShot.TakecreenShotMethod(screenshot);
				ReadExcel.Excel_Report_Generation(classname, return_result);
			}


			//List<WebElement> listOfLiElements = driver.findElements(By.xpath("//*[@id='ContentDivId_col_div']"));

		/*	
			List<WebElement> listOfLiElements = driver.findElements(By.xpath("//*[@id='fgp_container_list_3_row_0']"));
				//	findElement();

		//	element.click();
			for(int i=0; i< listOfLiElements.size(); i++){
				//listOfLiElements.get(i).click();
				if(listOfLiElements.get(i).getText().equalsIgnoreCase("Manage Suppliers")){
					listOfLiElements.get(i).findElement(By.xpath("//p[.='Manage Suppliers']")).click();;
				//	listOfLiElements.get(i).click();	
					break;
				}
http://localhost:8080/Gvst/
				*/
		/*	for(int i=0; i< listOfLiElements.size(); i++){
				//listOfLiElements.get(i).click();
				if(listOfLiElements.get(i).getText().equalsIgnoreCase("Manage Markets")){
					listOfLiElements.get(i).findElement(By.id("element_label_18"));
					listOfLiElements.get(i).click();	
					break;
				}*/

			/*	
				if(listOfLiElements.get(i).findElement(By.id("element_label_17")).getText() == "Manage Suppliers")
				     {
				      WebElement correctElement = listOfLiElements.get(i).findElement(By.id("element_label_17"));
				      //i =listOfLiElements.;
				      correctElement.click();
				      System.out.println("done");
				     }*/
			//	 }

			//*[@id="element_label_17"]// id("fgp_container_list_3_row_0"))/By.className("alist")




		}catch(Exception e)

		{
			System.out.println(e.getMessage());
		}

				return null;


	}
	public WebElement getWhenVisible(By locator, int timeout) {
	  //   element = null;
	    WebDriverWait wait = new WebDriverWait(driver, timeout);
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	    return element;
	}

	public void clickWhenReady(By locator, int timeout) {
	    WebDriverWait wait = new WebDriverWait(driver, timeout);
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
	    element.click();
	}
	public void sendKeyWhenReady(By locator, String text) {
	    WebDriverWait wait = new WebDriverWait(driver, 10);
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
	    element.sendKeys(text);
	}
	public WebElement checkPresence(By locator) {
	    WebDriverWait wait = new WebDriverWait(driver, 10);
	    WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	    return element;
	}
	
}
 